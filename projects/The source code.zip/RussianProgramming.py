import os
from tkinter import *
from tkinter import ttk
from tkinter import Text
from tkinter import messagebox
from lark import Lark
from lark.tree import Tree
from math import sqrt
from collections import ChainMap

#folders
folder = os.path.dirname(os.path.abspath(__file__))
folder_code = os.path.join(folder, 'savecode')
if not os.path.exists(folder_code):
    os.makedirs(folder_code)
file_name = None

def savefile():
    try:
        file_name = polenamefale.get()
        code = code_zone.get('1.0', 'end-1c')
        if file_name == '':
            messagebox.showerror('Ошибка имени', 'Имя не может быть пустым!')
        else:
            with open(os.path.join(folder_code, file_name + '.txt'), 'w', encoding='utf-8') as file:
                file.writelines(code)
            messagebox.showinfo('Сохранение', 'Файл успешно сохранён')
    except:
        messagebox.showerror('Ошибка сохранения', 'Произошла какая-то ошибка сохранения')

def openfile():
    try:
        file_name = polenamefale.get()
        if file_name == '':
            messagebox.showerror('Ошибка имени', 'Имя не может быть пустым!')
        else:
            with open(os.path.join(folder_code, file_name + '.txt'), 'r', encoding='utf-8') as file:
                code = file.read()
            code_zone.delete('1.0', 'end')
            code_zone.insert('1.0', code)
            tecnamefile.configure(text=f'открыт файл: {file_name}')
    except:
        messagebox.showerror('Ошибка открытия', 'Произошла какая-то ошибка. Возможно файл повреждён или не найден')

def startfile():
    print('RUN')
    parser = Lark(grammar, parser='lalr')
    code = code_zone.get('1.0', 'end-1c')
    
    tree = parser.parse(code)
    
    interpreter = Interpreter()
    interpreter.execute(tree)


#interpretator
grammar = r"""
?start: statement+

?statement: assign
          | func_def
          | if_stat
          | cycle
          | expr
          | return_stmt 


assign: NAME "=" expr

func_def: "функция" NAME "(" [params] ")" block
params: NAME ("," NAME)*
func_call: NAME "(" args ")"
args: expr ("," expr)*
return_stmt: "вернуть" expr 
if_stat: "если" expr block ("иначе" block)?
cycle: "цкпока" expr block
block: "{" statement+ "}"

?expr: number
     | string
     | func_call
     | var
     | print_call
     | input_call
     | to_int
     | to_float
     | to_str
     | qrt
     | modul
     | add
     | sub
     | mul
     | div
     | suq
     | ost
     | is_raven
     | is_notraven
     | is_bolse
     | is_mense
     | true
     | false
     | not_expr
     | and_expr
     | or_expr
     | "(" expr ")"

number: NUMBER
string: STRING
var: NAME
true: "истина"
false: "ложь"
and_expr: expr "и" expr
or_expr: expr "или" expr
not_expr: "не" expr

print_call: "напечатать" "(" expr ")"
input_call: "прочитать" "(" ")"
to_int: "число" "(" expr ")"
to_float: "дробное" "(" expr ")"
to_str: "строка" "(" expr ")"
qrt: "кореньиз" "(" expr ")"
modul: "модуль" "(" expr ")"

add: expr "+" expr
sub: expr "-" expr
mul: expr "*" expr
div: expr "/" expr
suq: expr "**" expr
ost: expr "%" expr

is_raven: expr "равно" expr
is_notraven: expr "неравно" expr
is_bolse: expr "больше" expr
is_mense: expr "меньше" expr

NAME: /[а-яА-ЯёЁ_][а-яА-ЯёЁ0-9_]*/
COMMENT: /\/\/\/(.|\n)*?\/\/\//

%import common.NUMBER
%import common.ESCAPED_STRING -> STRING
%ignore /[ \t\r\n]+/
%ignore COMMENT
"""

class ReturnException(Exception):
    def __init__(self, value):
        self.value = value

class Interpreter:
    def __init__(self):
        self.vars = {} # name: value
        self.functions = {} #name : {params: [], body: tree}
    
    def execute(self, tree: Tree):
        if tree.data == 'start':
            for stmt in tree.children:
                self.execute(stmt)
        
        elif tree.data == 'assign':
            name = tree.children[0].value
            value = self.evaluate(tree.children[1])
            self.vars[name] = value
        
        elif tree.data == 'if_stat':
            cond = self.evaluate(tree.children[0])
            if cond:
                self.execute_block(tree.children[1])  
            elif len(tree.children) > 2:
                self.execute_block(tree.children[2])  
            return None

        elif tree.data == 'cycle':
            while self.evaluate(tree.children[0]):
                self.execute_block(tree.children[1]) 
            return None
        
        elif tree.data == 'func_def':
            name = tree.children[0].value
            params = tree.children[1]  
            body = tree.children[2]    
            
            param_names = []
            if params:  
                if not isinstance(params.children, list):
                    param_nodes = [params]
                else:
                    param_nodes = params.children
                param_names = [p.value for p in param_nodes]
            
            self.functions[name] = {
                'params': param_names,
                'body': body
            }
            return None

        elif tree.data == 'print_call':
            val = self.evaluate(tree.children[0])
            print(val)

        elif tree.data == 'return_stmt':
            value = self.evaluate(tree.children[0])
            raise ReturnException(value)
        
        else:
            return self.evaluate(tree)
    
    def execute_block(self, block_tree):
        stmts = block_tree.children
        if not isinstance(stmts, list):
            stmts = [stmts]
        for stmt in stmts:
            self.execute(stmt)
    
        
    
    def evaluate(self, tree: Tree):
        # Вычисляет выражения и возвращает значения
        if tree.data == 'func_call':
            name = tree.children[0].value
            if len(tree.children) > 1:
                args_node = tree.children[1]
                if not isinstance(args_node.children, list):
                    args = [self.evaluate(args_node)]
                else:
                    args = [self.evaluate(arg) for arg in args_node.children]
            else:
                args = []
            return self.call_function(name, args)
        elif tree.data == 'number':
            return int(tree.children[0].value)
        elif tree.data == 'string':
            return tree.children[0].value[1:-1]
        elif tree.data == 'var':
            name = tree.children[0].value
            return self.vars[name]
        elif tree.data == 'add':
            return self.evaluate(tree.children[0]) + self.evaluate(tree.children[1])
        elif tree.data == 'sub':
            return self.evaluate(tree.children[0]) - self.evaluate(tree.children[1]) 
        elif tree.data == 'mul':
            return self.evaluate(tree.children[0]) * self.evaluate(tree.children[1])
        elif tree.data == 'div':
            return self.evaluate(tree.children[0]) / self.evaluate(tree.children[1])
        elif tree.data == 'suq':
            return self.evaluate(tree.children[0]) ** self.evaluate(tree.children[1])
        elif tree.data == 'ost':
            return self.evaluate(tree.children[0]) % self.evaluate(tree.children[1]) 
        elif tree.data == 'qrt':
            val = self.evaluate(tree.children[0])
            return sqrt(val)
        elif tree.data == 'to_int':
            val = self.evaluate(tree.children[0])
            return int(val)
        elif tree.data == 'to_str':
            val = self.evaluate(tree.children[0])
            return str(val)
        elif tree.data == 'to_float':
            val = self.evaluate(tree.children[0])
            return float(val)
    
        elif tree.data == 'true':
            return True
        elif tree.data == 'false':
            return False
        elif tree.data == 'and_expr':
            left = self.evaluate(tree.children[0])
            if not left:  #если лево ложь, право не вычисляем
                return False
            return self.evaluate(tree.children[1])

        elif tree.data == 'or_expr':
            left = self.evaluate(tree.children[0])
            if left:  #если лево истина, право не вычисляем
                return True
            return self.evaluate(tree.children[1])

        elif tree.data == 'not_expr':
            return not self.evaluate(tree.children[0])
        elif tree.data == 'is_raven':
            return self.evaluate(tree.children[0]) == self.evaluate(tree.children[1])
        elif tree.data == 'is_notraven':
            return self.evaluate(tree.children[0]) != self.evaluate(tree.children[1]) 
        elif tree.data == 'is_bolse':
            return self.evaluate(tree.children[0]) > self.evaluate(tree.children[1])
        elif tree.data == 'is_mense':
            return self.evaluate(tree.children[0]) < self.evaluate(tree.children[1])
        elif tree.data == 'input_call':
            val = input()
            return val
        elif tree.data == 'expr':
            return self.evaluate(tree.children[0])
        elif tree.data == 'modul':
            val = self.evaluate(tree.children[0])
            return abs(val)
        else:
            raise ValueError(f'Неизвестное выражение {tree.data}')
        
    def call_function(self, name, args):
        func = self.functions[name]
        params = func['params']
        body = func['body']
        
        # Сохраняем старые vars
        old_vars = self.vars
        
        # Создаём локальный словарь поверх глобального
        local_vars = {}
        for param, arg in zip(params, args):
            local_vars[param] = arg
        
        # Создаём цепочку: сначала локальные, потом глобальные
        self.vars = ChainMap(local_vars, old_vars)
        
        # Выполняем тело
        try:
            self.execute_block(body)
            result = None
        except ReturnException as e:
            result = e.value
        
        # Восстанавливаем старые переменные
        self.vars = old_vars
        
        return result
        


#GUI
root = Tk()
root.geometry('798x591')
root.resizable(False, False)
root.title('РуПи')

head = Frame(root, bg='gray')
body = Frame(root, bg='gray44')
root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)
root.rowconfigure(1, weight=50) 
head.grid(row=0, sticky='news')
body.grid(row=1, sticky='news')
#head
polenamefale = Entry(head, width=60, background='azure4')
tecnamefile = ttk.Label(head, text=f"открыт файл: {file_name}", background='gray')
btn_save = ttk.Button(head, width=20, text='Сохранить', command=savefile)
btn_open = ttk.Button(head, width=20, text='Открыть', command=openfile)
btn_start = ttk.Button(head, width=20, text='Запустить', command=startfile)
polenamefale.grid(row=0, column=0, sticky='news')
tecnamefile.grid(row=1, column=0, sticky='news')
btn_save.grid(row=0, column=1, sticky='news')
btn_open.grid(row=0, column=2, sticky='news')
btn_start.grid(row=0, column=3, sticky='news')
#body
code_zone = Text(body, width=97, height=34, background='gray10', foreground='blue', insertbackground='white')
scrollbar_y = Scrollbar(body, orient='vertical', command=code_zone.yview)
code_zone.configure(yscrollcommand=scrollbar_y.set) 
code_zone.grid(sticky='news')
scrollbar_y.grid(row=0, column=1, sticky='ns')

root.mainloop()



