import pygame
import os
import random


Global_RUN = True

def uprav(screen, WIDTH, HELIGHT, FPS, game_folder, img_folder):
    global Global_RUN
    global RUN
    RUN = True
    # цвета
    BLACK = (0, 0, 0)
    WHITE = (250, 250, 250)
    RED = (250, 0, 0)
    BLUE = (0, 0, 250)
    GREEN = (0, 250, 0)
    YELLOW = (250, 250, 0)
    FIOLLTTOVI = (83, 55, 122)
    GRAY = (128, 128, 128)
    colors = [YELLOW, GREEN, BLUE, RED, WHITE, BLACK]

    background = pygame.transform.scale(pygame.image.load(os.path.join(img_folder, 'cosmos.png')), (800, 800))
    mob_img = pygame.image.load(os.path.join(img_folder, 'meteor.png'))
    background_rect = background.get_rect()
    shrift = os.path.join(game_folder, "shrift", "RubikMoonrocks-Regular.ttf")
    shrift2 = os.path.join(game_folder, "shrift", "ofont.ru_Adventure Indiana.ttf")
    shrift3 = os.path.join(game_folder, "shrift", "ofont.ru_Serati.ttf")
    #font = pygame.font.Font(shrift, 60)

    def fontovik(shrift, size):
        return pygame.font.Font(shrift, size)

    clock = pygame.time.Clock()
    all_sprites = pygame.sprite.Group()

    class TextGroup:            #кастомный класс для текста
        def __init__(self):
            self.items = []

        def add(self, item):
            self.items.append(item)

        def update(self, mouse_pos):
            for item in self.items:
                item.update(mouse_pos)

        def draw(self, surface):
            for item in self.items:
                item.draw(surface)

        def handle_event(self, event):
            for item in self.items:
                item.handle_event(event)

    text_group = TextGroup()

    class InteractiveText:
        def __init__(
            self, 
            text, 
            pos, 
            font, 
            color, 
            hover_color = None, 
            angle=0, 
            on_click=None
        ):
            '''
            text - строка текста
            pos - кортеж (x, y) - позиция
            font - объект pygame.font.Font
            color - обычный цвет текста
            hover_color - цвет при наведении мышки
            angle - угол поворота текста
            on_click - функция, вызываемая при клике (или None)
            '''
            self.text = text
            self.pos = pos
            self.font = font
            self.color = color
            self.hover_color = hover_color
            self.angle = angle
            self.on_click = on_click

            self.hovered = False
            self.render_text()

        def render_text(self):
            # Рендерим текст и поворачиваем
            if self.hover_color != None:
                color = self.hover_color if self.hovered else self.color
            else:
                color = self.color
            self.text_surf = self.font.render(self.text, True, color)
            self.text_surf = pygame.transform.rotate(self.text_surf, self.angle)
            self.rect = self.text_surf.get_rect(topleft=self.pos)

        def update(self, mouse_pos):
            # Проверяем наведение мыши по прямоугольнику текста
            was_hovered = self.hovered
            self.hovered = self.rect.collidepoint(mouse_pos)
            if self.hovered != was_hovered:
                self.render_text()

        def draw(self, surface):
            surface.blit(self.text_surf, self.rect)

        def handle_event(self, event):
            # Обработка клика мыши по тексту
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.hovered and self.on_click:
                    self.on_click()

    class Mob(pygame.sprite.Sprite):        #метеор
            def __init__(self):
                pygame.sprite.Sprite.__init__(self)
                self.image_orig = mob_img
                self.image_orig.set_colorkey(BLACK)     #графика
                self.image = self.image_orig.copy()
                self.rect = self.image.get_rect()
                self.radius = 30                #радиус курга столкновения
                #pygame.draw.circle(self.image, RED, self.rect.center, self.radius)
                self.rect.x = random.randrange(WIDTH - self.rect.width)
                self.rect.y = random.randrange(-100, -40)
                self.speedy = random.randrange(1, 10)            #скорсти
                self.speedx = 0
                self.rot = 0
                self.rot_speed = random.randrange(-8, 8)
                self.last_update = pygame.time.get_ticks()

            def rotate(self):                   #крутяшка метеоров
                now = pygame.time.get_ticks()
                if now - self.last_update > 50:
                    self.last_update = now
                    self.rot = (self.rot + self.rot_speed) % 360
                    new_image = pygame.transform.rotate(self.image_orig, self.rot)
                    old_center = self.rect.center
                    self.image = new_image
                    self.image.set_colorkey(BLACK)          #обновление сетки пикселей
                    self.rect = self.image.get_rect()
                    self.rect.center = old_center

            def update(self):
                self.rotate()               #обновка
                self.rect.x += self.speedx
                self.rect.y += self.speedy
                if self.rect.top > HELIGHT + 10 or self.rect.left < -25 or self.rect.right > WIDTH + 20:
                    self.rect.x = random.randrange(WIDTH - self.rect.width)
                    self.rect.y = random.randrange(-100, -40)
                    self.speedy = random.randrange(1, 8)

    def new_mob():      #спавн метеоров
            m = Mob()
            all_sprites.add(m)

    for _ in range(10):
        new_mob()

    def vernut():
        global RUN
        RUN = False

    text_group.add(InteractiveText('Управление', pos=(20, 100), font=fontovik(shrift, 80), color=BLACK))
    text_group.add(InteractiveText('Движение - стрелочки', pos=(20, HELIGHT//2-60), font=fontovik(shrift3, 50), color=BLACK))
    text_group.add(InteractiveText('Стрелять - F', pos=(20, HELIGHT//2+10), font=fontovik(shrift3, 50), color=BLACK,))
    text_group.add(InteractiveText('Способность - space', pos=(20, HELIGHT//2+75), font=fontovik(shrift3, 50), color=BLACK))
    text_group.add(InteractiveText('ульта - E', pos=(20, HELIGHT//2+140), font=fontovik(shrift3, 50), color=BLACK))
    text_group.add(InteractiveText('вернуться', pos=(20, 750), font=fontovik(shrift3, 50), color=BLACK, hover_color=GRAY, on_click=vernut))



    
    while RUN:
        clock.tick(FPS)
        mouse_pos = pygame.mouse.get_pos()


        all_sprites.update()
        #отрисовка
        screen.blit(background, background_rect)
        all_sprites.draw(screen)  
        text_group.update(mouse_pos)                 #рисовка всех спрайтов
        text_group.draw(screen)

        pygame.display.flip()

        for event in pygame.event.get():
            # проверка для закрытия окна
            if event.type == pygame.QUIT:
                RUN = False
                Global_RUN = False
            text_group.handle_event(event)


def exting_uprav():
    if not Global_RUN:
        return False
    else:
        return True
 