import pygame
import os
import random
import baza


Global_RUN = True
txt_magaz = 'Добро пожаловать в мою лабораторию'
coins = 0
def obnova(screen, WIDTH, HELIGHT, FPS, game_folder, img_folder):
    global Global_RUN, txt_magaz
    global RUN
    RUN = True
    # цвета
    BLACK = (0, 0, 0)
    WHITE = (250, 250, 250)
    RED = (250, 0, 0)
    BLUE = (0, 0, 250)
    GREEN = (0, 250, 0)
    YELLOW = (250, 250, 0)
    FIOLLTTOVI = (83, 55, 122)
    GRAY = (128, 128, 128)
    colori = (152,90,22)
    colors = [YELLOW, GREEN, BLUE, RED, WHITE, BLACK]

    background = pygame.transform.scale(pygame.image.load(os.path.join(img_folder, 'cosmos.png')), (800, 800))
    mob_img = pygame.image.load(os.path.join(img_folder, 'meteor.png'))
    background_rect = background.get_rect()
    shrift = os.path.join(game_folder, "shrift", "RubikMoonrocks-Regular.ttf")
    shrift2 = os.path.join(game_folder, "shrift", "ofont.ru_Adventure Indiana.ttf")
    shrift3 = os.path.join(game_folder, "shrift", "ofont.ru_Serati.ttf")
    #font = pygame.font.Font(shrift, 60)

    def fontovik(shrift, size):
        return pygame.font.Font(shrift, size)

    clock = pygame.time.Clock()
    all_sprites = pygame.sprite.Group()

    class TextGroup:            #кастомный класс для текста
        def __init__(self):
            self.items = []

        def add(self, item):
            self.items.append(item)

        def update(self, mouse_pos):
            for item in self.items:
                item.update(mouse_pos)

        def draw(self, surface):
            for item in self.items:
                item.draw(surface)

        def handle_event(self, event):
            for item in self.items:
                item.handle_event(event)

    text_group = TextGroup()

    class InteractiveText:
        def __init__(
            self, 
            text, 
            pos, 
            font, 
            color, 
            hover_color = None, 
            angle=0, 
            on_click=None
        ):
            '''
            text - строка текста
            pos - кортеж (x, y) - позиция
            font - объект pygame.font.Font
            color - обычный цвет текста
            hover_color - цвет при наведении мышки
            angle - угол поворота текста
            on_click - функция, вызываемая при клике (или None)
            '''
            self.text = text
            self.pos = pos
            self.font = font
            self.color = color
            self.hover_color = hover_color
            self.angle = angle
            self.on_click = on_click

            self.hovered = False
            self.render_text()

        def render_text(self):
            # Рендерим текст и поворачиваем
            if self.hover_color != None:
                color = self.hover_color if self.hovered else self.color
            else:
                color = self.color
            self.text_surf = self.font.render(self.text, True, color)
            self.text_surf = pygame.transform.rotate(self.text_surf, self.angle)
            self.rect = self.text_surf.get_rect(topleft=self.pos)

        def update(self, mouse_pos):
            # Проверяем наведение мыши по прямоугольнику текста
            was_hovered = self.hovered
            self.hovered = self.rect.collidepoint(mouse_pos)
            if self.hovered != was_hovered:
                self.render_text()

        def draw(self, surface):
            surface.blit(self.text_surf, self.rect)

        def handle_event(self, event):
            # Обработка клика мыши по тексту
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.hovered and self.on_click:
                    self.on_click()

    class Mob(pygame.sprite.Sprite):        #метеор
            def __init__(self):
                pygame.sprite.Sprite.__init__(self)
                self.image_orig = mob_img
                self.image_orig.set_colorkey(BLACK)     #графика
                self.image = self.image_orig.copy()
                self.rect = self.image.get_rect()
                self.radius = 30                #радиус курга столкновения
                #pygame.draw.circle(self.image, RED, self.rect.center, self.radius)
                self.rect.x = random.randrange(WIDTH - self.rect.width)
                self.rect.y = random.randrange(-100, -40)
                self.speedy = random.randrange(1, 10)            #скорсти
                self.speedx = 0
                self.rot = 0
                self.rot_speed = random.randrange(-8, 8)
                self.last_update = pygame.time.get_ticks()

            def rotate(self):                   #крутяшка метеоров
                now = pygame.time.get_ticks()
                if now - self.last_update > 50:
                    self.last_update = now
                    self.rot = (self.rot + self.rot_speed) % 360
                    new_image = pygame.transform.rotate(self.image_orig, self.rot)
                    old_center = self.rect.center
                    self.image = new_image
                    self.image.set_colorkey(BLACK)          #обновление сетки пикселей
                    self.rect = self.image.get_rect()
                    self.rect.center = old_center

            def update(self):
                self.rotate()               #обновка
                self.rect.x += self.speedx
                self.rect.y += self.speedy
                if self.rect.top > HELIGHT + 10 or self.rect.left < -25 or self.rect.right > WIDTH + 20:
                    self.rect.x = random.randrange(WIDTH - self.rect.width)
                    self.rect.y = random.randrange(-100, -40)
                    self.speedy = random.randrange(1, 8)

    def new_mob():      #спавн метеоров
            m = Mob()
            all_sprites.add(m)

    for _ in range(10):
        new_mob()

    def vernut():
        global RUN
        RUN = False

    #переменые
    global coins, speed_shoot
    speed_shoot = baza.baza_out('speed_shoot')
    hp_player = baza.baza_out('hp')
    shield_player = baza.baza_out('sheld')
    kd_wall_player = baza.baza_out('kd_wall')
    kd_ult_player = baza.baza_out('kd_ult')
    damage_player_bullets = baza.baza_out('damage')
    pli_kombo = baza.baza_out('kombo')
    vampir = baza.baza_out('vampiries')
    coins = baza.baza_out('coins')
    
    #обновки
    def speed_shoot_upd():
        global coins, speed_shoot, txt_magaz
        if speed_shoot <= 100:
            txt_magaz = 'бысрее некуда!'
        elif coins >= 10000//speed_shoot:
            coins = round(coins - 10000//speed_shoot, 1)
            speed_shoot-=50
            baza.baza_in('speed_shoot', speed_shoot)
            baza.baza_in('coins', coins)
            txt_magaz = 'Спасибо за покупку!'
        else:
            txt_magaz = random.choice(['нехватка средств!', 'А денег подыскать?', 'Сначала деньги!'])


    text_group.add(InteractiveText('Улучшения', pos=(WIDTH//4-20, 3), font=fontovik(shrift, 80), color=BLACK))

    #oбновки
    text_group.add(InteractiveText('купить', pos=(80, 300), font=fontovik(shrift3, 20), color=colori, hover_color=GREEN, on_click=speed_shoot_upd))

    text_group.add(InteractiveText('вернуться', pos=(20, 750), font=fontovik(shrift3, 50), color=BLACK, hover_color=GRAY, on_click=vernut))

    def draw_text(surf, text, size, x, y, color):              #для вывода текста
        font = pygame.font.Font(shrift3, size)
        text_surface = font.render(text, True, color)
        text_rect = text_surface.get_rect()
        text_rect.midtop = (x, y)
        surf.blit(text_surface, text_rect)

    
    while RUN:
        clock.tick(FPS)
        mouse_pos = pygame.mouse.get_pos()
    
        #обновление характеристик!



        all_sprites.update()
        #отрисовка
        screen.blit(background, background_rect)
        all_sprites.draw(screen)  
        text_group.update(mouse_pos)                 #рисовка всех спрайтов
        text_group.draw(screen)


        draw_text(screen, f'характеристики корaбля: ', 20, WIDTH//2, 100, colori)
        draw_text(screen, f'скорострельность: {round(1000/speed_shoot, 1)}/сек., прочность: {hp_player}, щит: {shield_player}, урон: {damage_player_bullets}, регенерация: {vampir}', 18, WIDTH//2, 120, GRAY)
        draw_text(screen, f'перезарядка способности: {kd_wall_player if kd_wall_player > 0 else "без способности"}, перезарядка ульты: {kd_ult_player if kd_ult_player > 0 else "без ульты"}', 18, WIDTH//2, 140, GRAY)
        draw_text(screen, f'комбо-выстрелы: {pli_kombo if pli_kombo > 0 else "без комбо"}', 18, WIDTH//2, 160, GRAY)
        draw_text(screen, f'монет: {coins}', 18, 70, 50, colori)
        draw_text(screen, f'ускорение стрельбы', 15, 120, 265, GRAY)
        draw_text(screen, f'стоимость {10000//speed_shoot}', 15, 120, 280, GRAY)
        draw_text(screen, f'{txt_magaz}', 20, WIDTH-250, HELIGHT - 30, GRAY)

        

        pygame.display.flip()

        for event in pygame.event.get():
            # проверка для закрытия окна
            if event.type == pygame.QUIT:
                RUN = False
                Global_RUN = False
            text_group.handle_event(event)


def exting_obnov():
    if not Global_RUN:
        return False
    else:
        return True
 