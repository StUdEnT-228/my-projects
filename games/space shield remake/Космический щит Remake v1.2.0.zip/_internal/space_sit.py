import pygame
import os
import random
import baza

Global_RUN = True

def osn_game(screen, WIDTH, HELIGHT, FPS, game_folder, img_folder):
    global Global_RUN
    global RUN
    RUN = True
    # цвета
    BLACK = (0, 0, 0)
    WHITE = (250, 250, 250)
    RED = (250, 0, 0)
    BLUE = (0, 0, 250)
    GREEN = (0, 250, 0)
    YELLOW = (250, 250, 0)
    GRAY = (128, 128, 128)
    BOGROV = (72,6,7)
    colors = [YELLOW, GREEN, BLUE, RED, WHITE, BLACK]

    background = pygame.transform.scale(pygame.image.load(os.path.join(img_folder, 'cosmos.png')), (800, 800))
    mob_img = pygame.image.load(os.path.join(img_folder, 'meteor.png'))
    razmer_meora = [(50, 50), (75, 75), (100, 100)]
    background_rect = background.get_rect()
    player_img = pygame.image.load(os.path.join(img_folder, 'SpaceShip.png'))
    pulia_img = pygame.image.load(os.path.join(img_folder, 'пуля.png'))
    GODf = pygame.image.load(os.path.join(img_folder, 'GOD.png'))

    babax_anim = {}
    babax_anim['lg'] = []
    babax_anim['sm'] = []
    for i in range(7):
        filename = 'бах{}.png'.format(i+1)
        img = pygame.image.load(os.path.join(img_folder, filename))
        img.set_colorkey(BLACK)
        img_lg = pygame.transform.scale(img, (75, 75))
        img_sm = pygame.transform.scale(img, (32, 32))
        babax_anim['lg'].append(img_lg)
        babax_anim['sm'].append(img_sm)
    shrift = os.path.join(game_folder, "shrift", "RubikMoonrocks-Regular.ttf")
    shrift2 = os.path.join(game_folder, "shrift", "ofont.ru_Adventure Indiana.ttf")
    shrift3 = os.path.join(game_folder, "shrift", "ofont.ru_Serati.ttf")
    #font = pygame.font.Font(shrift, 60)

    def fontovik(shrift, size):
        return pygame.font.Font(shrift, size)

    
    #Группы и время
    clock = pygame.time.Clock()
    all_sprites = pygame.sprite.Group()
    bullets = pygame.sprite.Group()
    megabullets = pygame.sprite.Group()
    mobs = pygame.sprite.Group()

    class TextGroup:            #кастомный класс для текста
        def __init__(self):
            self.items = []

        def add(self, item):
            self.items.append(item)

        def update(self, mouse_pos):
            for item in self.items:
                item.update(mouse_pos)

        def draw(self, surface):
            for item in self.items:
                item.draw(surface)

        def handle_event(self, event):
            for item in self.items:
                item.handle_event(event)

    text_group = TextGroup()

    class InteractiveText:
        def __init__(
            self, 
            text, 
            pos, 
            font, 
            color, 
            hover_color = None, 
            angle=0, 
            on_click=None
        ):
            '''
            text - строка текста
            pos - кортеж (x, y) - позиция
            font - объект pygame.font.Font
            color - обычный цвет текста
            hover_color - цвет при наведении мышки
            angle - угол поворота текста
            on_click - функция, вызываемая при клике (или None)
            '''
            self.text = text
            self.pos = pos
            self.font = font
            self.color = color
            self.hover_color = hover_color
            self.angle = angle
            self.on_click = on_click

            self.hovered = False
            self.render_text()

        def render_text(self):
            # Рендерим текст и поворачиваем
            if self.hover_color != None:
                color = self.hover_color if self.hovered else self.color
            else:
                color = self.color
            self.text_surf = self.font.render(self.text, True, color)
            self.text_surf = pygame.transform.rotate(self.text_surf, self.angle)
            self.rect = self.text_surf.get_rect(topleft=self.pos)

        def update(self, mouse_pos):
            # Проверяем наведение мыши по прямоугольнику текста
            was_hovered = self.hovered
            self.hovered = self.rect.collidepoint(mouse_pos)
            if self.hovered != was_hovered:
                self.render_text()

        def draw(self, surface):
            surface.blit(self.text_surf, self.rect)

        def handle_event(self, event):
            # Обработка клика мыши по тексту
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.hovered and self.on_click:
                    self.on_click()
   
    #update player
    speed_shoot = baza.baza_out('speed_shoot')
    hp_player = baza.baza_out('hp')
    shield_player = baza.baza_out('sheld')
    kd_wall_player = baza.baza_out('kd_wall')
    kd_ult_player = baza.baza_out('kd_ult')
    damage_player_bullets = baza.baza_out('damage')
    pli_kombo = baza.baza_out('kombo')
    vampir = baza.baza_out('vampiries')

    class Bullet(pygame.sprite.Sprite): # пуля
        def __init__(self, x, y):
            pygame.sprite.Sprite.__init__(self)
            self.image = pulia_img                  #спрайт пули
            self.image.set_colorkey(BLACK)
            self.rect = self.image.get_rect()
            self.rect.bottom = y
            self.rect.centerx = x
            self.speedy = -10
            self.damage = damage_player_bullets

        def update(self):
            self.rect.y += self.speedy
            # убить, если он заходит за верхнюю часть экрана
            if self.rect.bottom < 0:
                self.kill()


    class MEGABullet(pygame.sprite.Sprite):
        def __init__(self, x, y):
            pygame.sprite.Sprite.__init__(self)
            self.image = GODf
            self.rect = self.image.get_rect()
            self.rect.bottom = y
            self.rect.centerx = x       #размещение пули
            self.speedy = -10

        def update(self):
            self.rect.y += self.speedy
            # убить, если он заходит за верхнюю часть экрана
            if self.rect.bottom < 0:
                self.kill()

    class Player(pygame.sprite.Sprite):
        def __init__(self):
            pygame.sprite.Sprite.__init__(self)
            self.image = player_img
            self.image.set_colorkey(BLACK)
            self.rect = self.image.get_rect()
            self.radius = 25                    # радиус круга столкновения
            # pygame.draw.circle(self.image, RED, self.rect.center, self.radius)
            self.rect.centerx = WIDTH / 2
            self.rect.bottom = HELIGHT - 10      # размещение коробля
            self.speedx = 0
            self.speedy = 0
            self.hp = hp_player             # прочность
            self.shield = shield_player          # щит
            self.shoot_delay = speed_shoot      # для зажатой стрельбы
            self.last_shot = pygame.time.get_ticks()

        def update(self):
            self.speedx = 0         # скорость по абцис
            self.speedy = 0         #скорость по ординат
            keystate = pygame.key.get_pressed()
            if keystate[pygame.K_LEFT]:         #лево
                self.speedx = -5
            if keystate[pygame.K_RIGHT]:        #право
                self.speedx = 5
            self.rect.x += self.speedx
            if keystate[pygame.K_UP]:           #вверх
                self.speedy = -5
            if keystate[pygame.K_DOWN]:         #вниз
                self.speedy = 5
            if keystate[pygame.K_f]:
                self.shoot()
            self.rect.y += self.speedy
            #чтоб не сбеджал закрая окна
            if self.rect.right > WIDTH:
                self.rect.right = WIDTH
            if self.rect.left < 0:
                self.rect.left = 0
            if self.rect.top < 0:
                self.rect.top = 0
            if self.rect.bottom > HELIGHT:
                self.rect.bottom = HELIGHT

        def shoot(self):            #стрельба
            now = pygame.time.get_ticks()
            if now - self.last_shot > self.shoot_delay:
                self.last_shot = now
                bullet = Bullet(self.rect.centerx, self.rect.top)
                all_sprites.add(bullet)
                bullets.add(bullet)

        def ulta12(self):                   #конец
            bullet2 = MEGABullet(WIDTH / 2, HELIGHT + 600)
            all_sprites.add(bullet2)
            megabullets.add(bullet2)



    class Mob(pygame.sprite.Sprite):        #метеор
            def __init__(self):
                pygame.sprite.Sprite.__init__(self)
                rzm = random.choice(razmer_meora)
                self.image_orig = pygame.transform.scale(mob_img, rzm)
                self.image_orig.set_colorkey(BLACK)     #графика
                self.image = self.image_orig.copy()
                self.rect = self.image.get_rect()
                self.radius = 30                #радиус курга столкновения
                #pygame.draw.circle(self.image, RED, self.rect.center, self.radius)
                self.rect.x = random.randrange(WIDTH - self.rect.width)
                self.rect.y = random.randrange(-100, -40)
                self.speedy = random.randrange(1, 5)            #скорсти
                self.speedx = 0
                self.rot = 0
                self.rot_speed = random.randrange(-8, 8)
                self.last_update = pygame.time.get_ticks()
                self.health = razmer_meora.index(rzm)+1

            def rotate(self):                   #крутяшка метеоров
                now = pygame.time.get_ticks()
                if now - self.last_update > 50:
                    self.last_update = now
                    self.rot = (self.rot + self.rot_speed) % 360
                    new_image = pygame.transform.rotate(self.image_orig, self.rot)
                    old_center = self.rect.center
                    self.image = new_image
                    self.image.set_colorkey(BLACK)          #обновление сетки пикселей
                    self.rect = self.image.get_rect()
                    self.rect.center = old_center

            def update(self):
                self.rotate()               #обновка
                self.rect.x += self.speedx
                self.rect.y += self.speedy
                if self.rect.top > HELIGHT + 10 or self.rect.left < -25 or self.rect.right > WIDTH + 20:
                    self.rect.x = random.randrange(WIDTH - self.rect.width)
                    self.rect.y = random.randrange(-100, -40)
                    self.speedy = random.randrange(1, 8)

    class Explosion(pygame.sprite.Sprite):
        def __init__(self, center, size):
            pygame.sprite.Sprite.__init__(self)
            self.size = size
            self.image = babax_anim[self.size][0]
            self.rect = self.image.get_rect()
            self.rect.center = center
            self.frame = 0
            self.last_update = pygame.time.get_ticks()
            self.frame_rate = 50
            
        def update(self):
            now = pygame.time.get_ticks()
            if now - self.last_update > self.frame_rate:
                self.last_update = now
                self.frame += 1
                if self.frame == len(babax_anim[self.size]):
                    self.kill()
                else:
                    center = self.rect.center
                    self.image = babax_anim[self.size][self.frame]
                    self.rect = self.image.get_rect()
                    self.rect.center = center

    def draw_text(surf, text, size, x, y, color):              #для вывода текста
        font = pygame.font.Font(shrift3, size)
        text_surface = font.render(text, True, color)
        text_rect = text_surface.get_rect()
        text_rect.midtop = (x, y)
        surf.blit(text_surface, text_rect)

    def draw_hp_bar(surf, x, y, pct, color):       #рисовка бара
        if pct < 0:
            pct = 0
        BAR_LENGTH = 100
        BAR_HEIGHT = 10
        fill = (pct / 100) * BAR_LENGTH
        outline_rect = pygame.Rect(x, y, BAR_LENGTH, BAR_HEIGHT)
        fill_rect = pygame.Rect(x, y, fill, BAR_HEIGHT)
        pygame.draw.rect(surf, color, fill_rect)
        pygame.draw.rect(surf, WHITE, outline_rect, 2)


    def new_mob():      #спавн метеоров
            m = Mob()
            all_sprites.add(m)
            mobs.add(m)

    for _ in range(10):
        new_mob()

    def vernut():
        global RUN
        RUN = False

    #переменые
    record = baza.baza_out('record')
    score = 0
    money = 0
    player = Player()
    all_sprites.add(player)      
    r = False
    text_group.add(InteractiveText('вернуться', pos=(10, HELIGHT-70), font=fontovik(shrift3, 30), color=BLACK, hover_color=GRAY, on_click=vernut))
    deat = InteractiveText("You're destroyed!", pos=(WIDTH//4, HELIGHT//2), font=fontovik(shrift2, 50), color=RED)
    
    while RUN:
        clock.tick(FPS)
        mouse_pos = pygame.mouse.get_pos()
        # ввод
        for event in pygame.event.get():
            # проверка для закрытия окна
            if event.type == pygame.QUIT:
                RUN = False
                Global_RUN = False
            text_group.handle_event(event)



        hits = pygame.sprite.groupcollide(mobs, bullets, False, True)

        for mob, bullet_list in hits.items():
            for bullet in bullet_list:
                mob.health -= bullet.damage   # вычитаем урон пули из здоровья моба
            if mob.health <= 0:
                score += 1
                money = round(money + 0.2, 1)
                expl = Explosion(mob.rect.center, 'lg')
                all_sprites.add(expl)
                mob.kill()      # удаляем моба, если здоровье закончилось
                new_mob()


        hits = pygame.sprite.groupcollide(mobs, megabullets, True, False)    #столкновение метеоров с ультой
        for hit in hits:
            score += 1
            expl = Explosion(hit.rect.center, 'lg')
            all_sprites.add(expl)

        
        # update
        all_sprites.update()    #обновление всех спрайтов
        #столкновение метеоров с кораблём
        hits = pygame.sprite.spritecollide(player, mobs, True, pygame.sprite.collide_circle)
        for hit in hits:
            player.hp -= 10     #отнимаем хп
            expl = Explosion(hit.rect.center, 'sm')
            all_sprites.add(expl)
            new_mob()
            
            if player.hp <= -1 and not r:          # здох
                r = True
                player.kill()
                text_group.add(deat)
                time_to_exit = pygame.time.get_ticks()
                baza.baza_in('record', record)
                coins = baza.baza_out('coins')
                baza.baza_in('coins', round(coins + money, 1))
            if r and pygame.time.get_ticks() > time_to_exit + 2000:
                RUN = False          # стоп

        #рекорд
        if record < score:
            record = score
                #рисовка баров
        '''
        draw_hp_bar(screen, WIDTH / 2 - 50, HEIGTH - 20, player.shield, BLUE)
        draw_hp_bar(screen, WIDTH - 120, HEIGTH - 20, player.kd / 2, GREEN)
        draw_hp_bar(screen, WIDTH - 120, HEIGTH - 40, player.kdul / 20, YELLOW)'''



        all_sprites.update()
        text_group.update(mouse_pos)
        #отрисовка
        screen.blit(background, background_rect)
        all_sprites.draw(screen)  
        draw_text(screen, f'уничтожено {str(score)} метеоров!  твой рекорд {str(record)}', 18, WIDTH / 2, 20, GRAY)
        draw_text(screen, f'собрано {str(money)} монет.', 18, WIDTH / 2, 40, GRAY)
        draw_hp_bar(screen, WIDTH / 2 - 50, HELIGHT - 20, player.hp/(hp_player/100), RED)
        text_group.draw(screen)

        pygame.display.flip()



def exting_game():
    if Global_RUN:
        return True
    else:
        return False

        
 

