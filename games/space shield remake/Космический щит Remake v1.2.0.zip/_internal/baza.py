import sqlite3
def bazacreate():
    connection = sqlite3.connect('USER.db')
    cursor = connection.cursor()

    #таблицa
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Userdata (
                id INTEGER PRIMARY KEY,
                coins INTEGER,
                speed_shoot INTEGER,
                hp INTEGER,
                sheld INTEGER,
                kd_wall INTEGER,
                kd_ult INTEGER,
                damage INTEGER,
                kombo INTEGER,
                vampiries INTEGER,
                record INTEGER

                )
    ''')

    '''
    #update player
        speed_shoot = 1000
        hp_player = 50
        shield_player = 0
        kd_wall_player = 1000
        kd_ult_player = 5000
        damage_player_bullets = 1
        pli_kombo = 10
        vampir = 0
    '''
    # Сохраняем изменения и закрываем соединение
    connection.commit()


    cursor.execute('SELECT * FROM Userdata')
    s = cursor.fetchall()

    if not s:  # Если таблица пустая
        cursor.execute('INSERT INTO Userdata (coins, speed_shoot, hp, sheld, kd_wall, kd_ult, damage, kombo, vampiries, record) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                        (0, 1000, 50, 0, -10, -10, 1, -10, 0, 0))
        connection.commit()
    connection.close()

def baza_out(txt : str):
    connection = sqlite3.connect('USER.db')
    cursor = connection.cursor()
    cursor.execute(f'SELECT {txt} FROM Userdata')
    s = cursor.fetchone()
    connection.close()
    return s[0]

def baza_in(txt : str, upd):
    connection = sqlite3.connect('USER.db') 
    cursor = connection.cursor()
    cursor.execute(f'UPDATE Userdata SET {txt} = ?', (upd,))
    connection.commit()
    connection.close()